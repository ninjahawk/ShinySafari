
let points = 0;
const shinyButton = document.getElementById('shiny-button');
const memeContainer = document.getElementById('meme-container');
const memeImage = document.getElementById('meme-image');
const scoreDisplay = document.getElementById('score');

shinyButton.addEventListener('click', () => {
    shinyButton.style.display = 'none'; // Hide button
    let randomNumber = Math.floor(Math.random() * 5) + 1; // Updated shiny odds to 1/5
    if (randomNumber === 1) {
        points++;
        scoreDisplay.innerText = `Shinies Caught: ${points}`;
        memeImage.src = '3FDAF7BC-7FBB-47ED-819F-0473A70DAED7.webp'; // Show shiny Pokémon image
        memeContainer.style.bottom = '25%'; // Position shiny Pokémon image
        memeImage.style.height = '300px'; // Make shiny Pokémon image larger
        memeContainer.style.display = 'block';
        setTimeout(() => {
            memeContainer.style.display = 'none';
            shinyButton.style.display = 'block'; // Show button immediately after image disappears
        }, 500); // 0.5 second display time
    } else {
        memeImage.src = 'F4BA218B-36C2-416B-A217-329EB6FF6EEC.png'; // Show non-shiny Pokémon image
        memeContainer.style.bottom = '25%'; // Position non-shiny Pokémon image slightly lower
        memeImage.style.height = '200px'; // Make non-shiny Pokémon image larger
        memeContainer.style.display = 'block';
        setTimeout(() => {
            memeContainer.style.display = 'none';
            shinyButton.style.display = 'block'; // Show button immediately after image disappears
        }, 500); // 0.5 second display time
    }
});
